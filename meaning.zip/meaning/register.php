<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registration Form</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: mediumslateblue;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    form {
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
        max-width: 400px;
        width: 100%;
    }
    input[type="text"],
    input[type="email"],
    input[type="password"] {
        width: calc(100% - 22px);
        padding: 10px;
        margin: 8px 0;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
    }
    input[type="submit"]:hover {
        background-color: #45a049;
    }
    .password-toggle {
        display: flex;
        align-items: center;
    }
    .password-toggle input[type="checkbox"] {
        margin-right: 5px;
    }
    .password-toggle label {
        font-size: 14px;
    }
    .float-end {
  float: right;

}
.user {
  padding: 18px;
}
.logimg {
  height: 0.5cm;
}
</style>
</head>
<body>
    <form action="connect.php" method="POST">
        <h2 style="text-align: center;">Registration Form</h2>
        <label for="fname">Username:</label>
        <input type="text" name="username" required>


    
        <div class="form-group">
                <label for="gender">Gender</label>
                <div>
                  <label for="male" class="radio-inline"
                    ><input
                      type="radio"
                      name="gender"
                      value="m"
                      id="male"
                    />Male</label
                  >
                  <label for="female" class="radio-inline"
                    ><input
                      type="radio"
                      name="gender"
                      value="f"
                      id="female"
                    />Female</label>
                </div>
        <label for="password" >Password:</label>
        <div class="password-toggle">
            <input type="password" name="password" id="show" required>
            <input type="checkbox" name="" id="show" onclick="myFunction()">
            <label for="showPassword">Show Password</label>
            
        </div>

        <label for="confirmPassword">Confirm Password:</label>
        <input type="password" name="confirmPassword" required>

        <input type="submit" value="Register">
        
    </form>

    <script type="text/javascript">
    function myFunction()
    {
        var show = document.getElementById('show');
        if (show.type=='password') {
            show.type='text';
        }
        else {
            show.type='password';
        }
    }
</script>

</body>
</html>
