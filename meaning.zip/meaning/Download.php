<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Uploaded Resources</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 20px;
    }
    .resource-list {
        max-width: 800px;
        margin: 0 auto;
        background-color: #fff;
        border-radius: 8px;
        padding: 20px;
    }
    .resource {
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #ccc;
        padding: 10px 0;
    }
    .resource-name {
        flex: 1;
    }
    .resource-type {
        margin-right: 20px;
    }
    .download-button {
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        padding: 8px 16px;
        cursor: pointer;
    }
    .download-button:hover {
        background-color: #45a049;
    }
    .pagination {
        text-align: right;
        margin-top: 20px;
    }
    .search-container {
        margin-bottom: 20px;
    }
    .search-container input[type=text] {
        padding: 10px;
        margin-right: 10px;
        border-radius: 4px;
        border: 1px solid #ccc;
    }
    .search-button {
        background-color: #008CBA;
        color: white;
        border: none;
        border-radius: 4px;
        padding: 10px 20px;
        cursor: pointer;
    }
    .search-button:hover {
        background-color: #005f7f;
    }
    .upload-button {
        background-color: #008CBA;
        color: white;
        border: none;
        border-radius: 4px;
        padding: 10px 20px;
        cursor: pointer;
    }
    .upload-button:hover {
        background-color: #005f7f;
    }
    .header {
        font-weight: bold;
        font-size: 18px;
        margin-bottom: 10px;
    }
    
</style>
</head>
<body>
    <div class="resource-list">
        <div class="header">Uploaded Resources</div>
        <div class="search-container">
            <input type="text" id="searchInput" placeholder="Search by resource name">
            <button class="search-button" onclick="searchResources()">Search</button>
        </div>
        <div class="upload-container">
            <input type="file" id="fileInput" accept=".pdf,.docx,.ppt,.pptx,.doc,.mp4">
            <button class="upload-button" onclick="uploadFile()">Upload</button>
        </div>
        <div class="resources">
            <div class="resource">
                <div class="resource-name">File Name</div>
                <div class="resource-type">Type</div>
                <div></div>
            </div>
            <!-- Resources will be dynamically added here -->
        </div>
        <div class="pagination">
            <button onclick="previousPage()">Previous</button>
            <button onclick="nextPage()">Next</button>
        </div>
    </div>

    <script>
        // Sample data for resources (you can replace it with your data)
        var resources = [
            { name: "Resource 1", type: "PDF" },
            { name: "Resource 2", type: "Video" },
            { name: "Resource 3", type: "Document" },
            { name: "Resource 4", type: "Presentation" },
            { name: "Resource 5", type: "Image" }
        ];

        var currentPage = 1;
        var resourcesPerPage = 3;

        function displayResources() {
            var resourcesDiv = document.querySelector('.resources');
            resourcesDiv.innerHTML = '';

            var startIndex = (currentPage - 1) * resourcesPerPage;
            var endIndex = startIndex + resourcesPerPage;
            var displayedResources = resources.slice(startIndex, endIndex);

            displayedResources.forEach(function(resource) {
                var resourceDiv = document.createElement('div');
                resourceDiv.classList.add('resource');
                resourceDiv.innerHTML = `
                    <div class="resource-name">${resource.name}</div>
                    <div class="resource-type">${resource.type}</div>
                    <button class="download-button" onclick="downloadResource('${resource.name}')">Download</button>
                `;
                resourcesDiv.appendChild(resourceDiv);
            });
        }

        function nextPage() {
            var totalPages = Math.ceil(resources.length / resourcesPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                displayResources();
            }
        }

        function previousPage() {
            if (currentPage > 1) {
                currentPage--;
                displayResources();
            }
        }

        function searchResources() {
            var input = document.getElementById("searchInput").value.toUpperCase();
            var filteredResources = resources.filter(function(resource) {
                return resource.name.toUpperCase().includes(input);
            });
            currentPage = 1;
            displayResources();
        }

        function uploadFile() {
            var fileInput = document.getElementById('fileInput');
            var file = fileInput.files[0];
            var fileName = file.name;
            var fileType = fileName.split('.').pop().toUpperCase();
            resources.push({ name: fileName, type: fileType });
            currentPage = 1;
            displayResources();
        }

        function downloadResource(resourceName) {
            // Simulating download for demonstration purpose
            alert('Downloading: ' + resourceName);
        }

        displayResources();
    </script>
</body>
</html>
