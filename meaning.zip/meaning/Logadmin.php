<?php
$host="localhost";
$user="root";
$password="";
$db="learnhome";
session_start();
$data=mysqli_connect($host,$user,$password,$db);
if($data===false)
{
    die("connection error");
}
if($_SERVER["REQUEST_METHOD"]=="POST")
{
    $username=$_POST["username"];
    $password=$_POST["password"];
    $sql="select * from login where username='".$username."' AND password='".$password."'";
    $result=mysqli_query($data,$sql);
    $row=mysqli_fetch_array($result);
    if($row["usertype"]=="user")
    {
        $_SESSION["username"]=$username;
        header("location:home.php");
    }
    elseif($row["usertype"]=="admin")
    {
        $_SESSION["username"]=$username;
        header("location:adminhome.php");
    }
    else
    {
        
        header("location:Logadmin.php");
        
    }
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Login</title>
	<style>
		body {
    font-family: Arial, sans-serif;
    background-color: mediumslateblue;
}
body, html {
    margin: 0;
	padding: 0;
}
.login  {
    display: block;
    margin-bottom: 5px;
}

.login input[type="text"],
.login input[type="password"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;

}
button[type="submit"] {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    border: none;
    color: #fff;
    border-radius: 3px;
    cursor: pointer;
}

button[type="submit"]:hover {
    background-color: #0056b3;
}
.logimg {
    height: 1cm;
}
.header {
  overflow: hidden;
  background-color: #f1f1f1;
  position: fixed; /* Set the header to be fixed */
  width: 100%; /* Make the header span the full width */
  z-index: 1000; /* Ensure the header stays on top of other content */
}
	</style>
</head>

<body>
<div class="header">
<h1><img src="images/favicon/favicon.ico" class="logimg"> Welcome at Learn at home<h1>
</div>

<div class="login">
<br><br><br><br><br><br><br>
  <form action = "#" method = "POST">
<center>
    <div style="width:400px"; boarder: 1;>
    <br><br><br><br>
    <label>Username</label>

    <br><br>
	<input type="text" name ="username" required>
    <br><br>
	<label>Password</label>
    <br><br>
	<input type="password" name="password" required>
    <br><br><br>
	<button type="submit" class="log">Login</button>
    <br><br><br>
    <a href="register.php">Don't have an account? Register</a>

</div>
</center>
	</form>
</div>

</body>
</html>
