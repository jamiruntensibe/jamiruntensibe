<?php
$username = $_POST['username'];
$gender = $_POST['gender'];
$password = $_POST['password'];
	

	// Database connection
	$conn = new mysqli('localhost','root','','learnhome');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into login(username, gender, password) values(?, ?, ?)");
		$stmt->bind_param("sss", $username, $gender, $password);
		$execval = $stmt->execute();
		echo $execval;
		header("location:logadmin.php");
		echo "Registration successfully...";
		$stmt->close();
		$conn->close();
	}
?>
