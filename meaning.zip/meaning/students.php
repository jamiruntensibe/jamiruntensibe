<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "learnhome";
session_start();
if(!isset($_SESSION['username']))
{
    header("location:logadmin.php");
}


// Create connection
$conn = mysqli_connect($host, $user, $password, $db);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// echo "Connected successfully";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin</title>
	<link rel="icon" type="image/x-icon" href="images/favicon/favicon.ico">
	
	<!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
		body {
    font-family: Arial, sans-serif;
    background-color: mediumslateblue;
}
	/* Reset some default styles */
body, html {
    margin: 0;
	padding: 0;}
	/* Style the header with a grey background and some padding */
/* Style the header */
.header {
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 20px 10px;
  position: fixed; /* Set the header to be fixed */
  width: 100%; /* Make the header span the full width */
  z-index: 1000; /* Ensure the header stays on top of other content */
}

/* Style the header links */
.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  line-height: 25px;
  border-radius: 4px;
}

/* Style the logo link */
.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

/* Change the background color on mouse-over */
.header a:hover {
  background-color: #ddd;
  color: black;
}

/* Style the active/current link */
.header a.active {
  background-color: dodgerblue;
  color: white;
}

/* Float the link section to the right */
.header-right {
  float: right;
}

/* Add padding to the content to prevent it from being covered by the fixed header */
.content {
  padding-top: 25px; /* Adjust the value according to the height of your header */
}

/* Add media queries for responsiveness - when the screen is 500px wide or less, stack the links on top of each other */
@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  .header-right {
    float: none;
  }
}
	
	/* The side navigation menu */
.sidebar {
  margin-top: 80px; /* Adjust according to your header's height */
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: calc(100% - 80px); /* Adjust according to your header's height */
  overflow: auto;
}

/* Sidebar links */
.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}

/* Active/current link */
.sidebar a.active {
  background-color: #04AA6D;
  color: white;
}

/* Links on mouse-over */
.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

/* Page content */
.content {
  margin-left: 220px; /* Adjust according to your sidebar's width */
  padding: 16px;
}

div.content {
  margin-left: 184px;
  padding: 1px 16px;
  height: 1000px;
}
	{box-sizing:border-box}

/* Slideshow container */
.slideshow-container {
  max-width: 1400px;
  position: relative;
  margin: auto;
}

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  margin-top: -22px;
  padding: 16px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}


.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}
.float-end {
  float: right;

}

.user {
  padding: 18px;
}
.logimg {
  height: 0.5cm;
}

</style>
	
	</head>
<body>
<div class="header">
<a href="adminhome.php" class="logo"><img src="images/favicon/favicon.ico" class="logimg">  Learn at home Admin</a>
  <div>
   
  <?php if(isset($_SESSION['username'])){?>
<div class="float-end"><a href="adminlogout.php"><i class="fa fa-sign-out"></i>Logout</a></div>

<?php
}
else{
  ?>
  <a id="login" href="adminlogin.php"><i class="fa fa-sign-in"></i>Login</a>
<?php } ?>
<div class="float-end"><a href="aboutAdmin.php">About us</a></div>
  </div>
</div>
	<!-- The sidebar -->
  <div class="sidebar">
<a class="active" href="adminhome.php">Home</a>
  <a href="students.php">Manage Students</a>
  <a href="manageUsers.php">Manage Admins</a>
  <a href="s1admin.php">S1 Resources</a>
  <a href="s2admin.php">S2 Resources</a>
  <a href="s3admin.php">S3 Resources</a>
  <a href="s4admin.php">S4 Resources</a>
  <a href="s5admin.php">S5 Resources</a>
  <a href="s6admin.php">S6 Resources</a>
  <a href="adminvideo.php">Video</a>
</div>
<!-- Page content -->
	
<div class="content">
<nav class="navbar navbar-light justify-content-center fs-3 mb-5" style="background-color: #00ff5573;">
    Lear at home
  </nav>

  <div class="container">
    <?php
    if (isset($_GET["msg"])) {
      $msg = $_GET["msg"];
      echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
      ' . $msg . '
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    }
    ?>
    <a href="add-new.php" class="btn btn-dark mb-3">Add New</a>

    <table class="table table-hover text-center">
      <thead class="table-dark">
        <tr>
          <th scope="col">ID</th>
          <th scope="col">First Name</th>
          <th scope="col">Last Name</th>
          <th scope="col">Email</th>
          <th scope="col">Gender</th>
          <th scope="col">Password</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $sql = "SELECT * FROM `students`";
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
        ?>
          <tr>
            <td><?php echo $row["id"] ?></td>
            <td><?php echo $row["first_name"] ?></td>
            <td><?php echo $row["last_name"] ?></td>
            <td><?php echo $row["email"] ?></td>
            <td><?php echo $row["gender"] ?></td>
            <td><?php echo $row["pasword"] ?></td>
            <td>
              <a href="edit.php?id=<?php echo $row["id"] ?>" class="link-dark"><i class="fa-solid fa-pen-to-square fs-5 me-3"></i></a>
              <a href="delete.php?id=<?php echo $row["id"] ?>" class="link-dark"><i class="fa-solid fa-trash fs-5"></i></a>
            </td>
          </tr>
        <?php
        }
        ?>
      </tbody>
    </table>
  </div>

  <!-- Bootstrap -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

 
</div>
</body>
</html>