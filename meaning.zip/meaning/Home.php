<?php
session_start();
if(!isset($_SESSION['username']))
{
    header("location:logadmin.php");
}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>
	<link rel="icon" type="image/x-icon" href="images/favicon/favicon.ico">
<style>
		body {
    font-family: Arial, sans-serif;
    background-color: mediumslateblue;
}
	/* Reset some default styles */
body, html {
    margin: 0;
	padding: 0;}
	/* Style the header with a grey background and some padding */
/* Style the header */
.header {
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 20px 10px;
  position: fixed; /* Set the header to be fixed */
  width: 100%; /* Make the header span the full width */
  z-index: 1000; /* Ensure the header stays on top of other content */
}

/* Style the header links */
.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  line-height: 25px;
  border-radius: 4px;
}

/* Style the logo link */
.header a.logo {
  font-size: 25px;
  font-weight: bold;
  height:0.5cm;
}
.logimg {
  height: 0.5cm;
}

/* Change the background color on mouse-over */
.header a:hover {
  background-color: #ddd;
  color: black;
}

/* Style the active/current link */
.header a.active {
  background-color: dodgerblue;
  color: white;
}

/* Float the link section to the right */
.header-right {
  float: right;
}

/* Add padding to the content to prevent it from being covered by the fixed header */
.content {
  padding-top: 25px; /* Adjust the value according to the height of your header */
}

/* Add media queries for responsiveness - when the screen is 500px wide or less, stack the links on top of each other */
@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  .header-right {
    float: none;
  }
}
	
	/* The side navigation menu */
.sidebar {
  margin-top: 80px; /* Adjust according to your header's height */
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: calc(100% - 80px); /* Adjust according to your header's height */
  overflow: auto;
}

/* Sidebar links */
.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}

/* Active/current link */
.sidebar a.active {
  background-color: #04AA6D;
  color: white;
}

/* Links on mouse-over */
.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

/* Page content */
.content {
  margin-left: 220px; /* Adjust according to your sidebar's width */
  padding: 16px;
}

div.content {
  margin-left: 184px;
  padding: 1px 16px;
  height: 1000px;
}
	{box-sizing:border-box}

/* Slideshow container */
.slideshow-container {
  max-width: 1400px;
  position: fixed;
  margin: auto;
  width:100%;
}

/* Hide the images by default */
.mySlides {
  display: none;
  
  
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  margin-top: -22px;
  padding: 16px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 17%;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}


.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}
.img {
  height: 10cm;
}

.card-body {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}
.float-end {
  float: right;

}
.user {
  padding: 18px;
}
/* Dropdown Button */
.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px;
  font-size: 16px;
  min-width: 200px;
  border: none;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 200px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd;}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
	<head>
	</head>
<body>
	<div class="header">
  <a href="home.php" class="logo"><img src="images/favicon/favicon.ico" class="logimg">  Learn at home</a>
  <div class="header-right">
    
    <?php if(isset($_SESSION['username'])){?>
<div class="float-end"><a href="logout.php"><i class="fa fa-sign-out"></i>Logout</a></div>

<?php
}
else{
  ?>
  <a id="login" href="login.php"><i class="fa fa-sign-in"></i>Login</a>
<?php } ?>
<div class="float-end"><a href="about.php">About us</a></div>
  </div>
</div>
	<!-- The sidebar -->
  <div class="sidebar">
 
 <div class="dropdown">
 <button class="dropbtn">Learning Resources</button>
 <div class="dropdown-content">
   
 <a href="s1.php">S1 Resources</a>
 <a href="s2.php">S2 Resources</a>
 <a href="s3.php">S3 Resources</a>
 <a href="s4.php">S4 Resources</a>
 <a href="s5.php">S5 Resources</a>
 <a href="s6.php">S6 Resources</a>
 <a href="video.php">Video</a>
 </div>
</div>

</div>


<!-- Page content -->
	
<div class="content">
<!-- Slideshow container -->
<div class="slideshow-container">

  <!-- Full-width images with number and caption text -->
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img src="images/Remote_learning.png" class="img" style="width:101.5%">
  </div>

  <div class="mySlides fade">
    <div class="numbertext">2 / 3</div>
    <img src="images/learningLogo.jpg" class="img" style="width:101.5%">
  </div>

  <div class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="images/learningLogo.jpg" class="img" style="width:101.%">
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>
</div>


	<script>

	let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}
</script>
 
</body>
</html>
