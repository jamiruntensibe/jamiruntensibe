
<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "learnhome";
session_start();

// Create connection
$conn = mysqli_connect($host, $user, $password, $db);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// echo "Connected successfully";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>
	<link rel="icon" type="image/x-icon" href="images/favicon/favicon.ico">
<style>
		body {
    font-family: Arial, sans-serif;
    background-color: mediumslateblue;
}

h3 {
  color: #999;
}
	/* Reset some default styles */
body, html {
    margin: 0;
	padding: 0;}
	/* Style the header with a grey background and some padding */
/* Style the header */
.header {
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 20px 10px;
  position: fixed; /* Set the header to be fixed */
  width: 100%; /* Make the header span the full width */
  z-index: 1000; /* Ensure the header stays on top of other content */
}

/* Style the header links */
.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  line-height: 25px;
  border-radius: 4px;
}

/* Style the logo link */
.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

/* Change the background color on mouse-over */
.header a:hover {
  background-color: #ddd;
  color: black;
}

/* Style the active/current link */
.header a.active {
  background-color: dodgerblue;
  color: white;
}

/* Float the link section to the right */
.header-right {
  float: right;
}

/* Add padding to the content to prevent it from being covered by the fixed header */
.content {
  padding-top: 25px; /* Adjust the value according to the height of your header */
}

/* Add media queries for responsiveness - when the screen is 500px wide or less, stack the links on top of each other */
@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  .header-right {
    float: none;
  }
}
	
	/* The side navigation menu */
.sidebar {
  margin-top: 80px; /* Adjust according to your header's height */
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: calc(100% - 80px); /* Adjust according to your header's height */
  overflow: auto;
}

/* Sidebar links */
.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}

/* Active/current link */
.sidebar a.active {
  background-color: #04AA6D;
  color: white;
}

/* Links on mouse-over */
.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

/* Page content */
.content {
  margin-left: 220px; /* Adjust according to your sidebar's width */
  padding: 16px;
}

div.content {
  margin-left: 184px;
  padding: 1px 16px;
  height: 100vh;
}
  /* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}
.col-xl {
  background-color: yellow;
  padding-top: 40px;
  width: 20%;
  height:3cm;
  margin-top: 4cm;
}

.container {
  position: absolute;
  right: 0;
  width: 80vh;
  height: 100vh;
  background: #f1f1f1;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}
.container .contet {
position: relative;
margin-top: 10vh;
min-height: 90vh;
margin-left: 220px; /* Adjust according to your sidebar's width */
  padding: 16px;
  
}
.container .contet .cards {
  padding: 20px;
  display: flex;
  align-items: center;
  justify-content:  space-between;
  flex-wrap: wrap;
}
.contet .cards .card {
  width: 350px;
  height: 150px;
  background: white;
  margin: 20px 15px;
  display: flex;
  align-items: center;
  justify-content: space-around;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2) 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.column {
  float: left;
  width: 30%;
  margin-bottom: 16px;
  padding: 4px 15px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}
@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
.float-end {
  float: right;

}
.user {
  padding: 18px;
}
.logimg {
  height: 0.5cm;
}

.prob {
        font-family: Arial, sans-serif;
        margin-left: 32px;
        background-color: white;
    }
    .proba {
        font-family: Arial, sans-serif;
        margin-left: 40px;
    
    padding-bottom: 10px;
    padding-top: 10px;
    }
    /* Dropdown Button */
.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px;
  font-size: 16px;
  min-width: 200px;
  border: none;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 200px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd;}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
	<head>
	</head>
<body>
  
<div class="header">
<a href="adminhome.php" class="logo"><img src="images/favicon/favicon.ico" class="logimg">  Learn at home Admin</a>
  <div>
  
  <?php if(isset($_SESSION['username'])){?>
<div class="float-end"><a href="adminlogout.php"><i class="fa fa-sign-out"></i>Logout</a></div>

<?php
}
else{
  ?>
  <a id="login" href="logadmin.php"><i class="fa fa-sign-in"></i>Login</a>
<?php } ?>
<div class="float-end"><a href="aboutAdmin.php">About us</a></div>
  </div>
</div>
	<!-- The sidebar -->
  <div class="sidebar">
  <div class="dropdown">
 <button class="dropbtn">Learning Resources</button>
 <div class="dropdown-content">
  
<a href="manageUsers.php">Manage Users</a>
  <a href="s1admin.php">S1 Resources</a>
  <a href="s2admin.php">S2 Resources</a>
  <a href="s3admin.php">S3 Resources</a>
  <a href="s4admin.php">S4 Resources</a>
  <a href="s5admin.php">S5 Resources</a>
  <a href="s6admin.php">S6 Resources</a>
  <a href="adminvideo.php">Video</a>
  </div>
  </div>
</div>


<!-- Page content -->

<div class="content">
  <div class="row">
    <div class="column">
    <br><br><br><br><br>
<div class="contet">

    <div class="cards">
      <div class="card">
        <div class="box">
          <h1>
          <?php
    $con = mysqli_connect("localhost","root","","learnhome");
    $dash_category_query = "SELECT * FROM login WHERE usertype='admin'";
    $dash_category_query_run = mysqli_query($con, $dash_category_query);
    if($dash_category_total = mysqli_num_rows($dash_category_query_run))
    {
      echo'<h1 class="mb-0">'.$dash_category_total.'</h1>';

    } 
    else
    {
     echo'<h1 class="mb-0">No data</h1>'; 
    }
    ?>
          </h1>
          <h3>Admins</h3>
        </div>
        <div class="icon-case">
          <img src="images/favicon/favicon.ico" alt=""></div>
      </div>
    </div>
    <div class="content-2"></div>
  </div>
</div>
  
<div class="column">
<br><br><br><br><br>
  <div class="contet">

    <div class="cards">
      <div class="card">
        <div class="box">
        <?php
    $con = mysqli_connect("localhost","root","","learnhome");
    $dash_category_query = "SELECT * FROM login WHERE usertype='user'";
    $dash_category_query_run = mysqli_query($con, $dash_category_query);
    if($dash_category_total = mysqli_num_rows($dash_category_query_run))
    {
      echo'<h1 class="mb-0">'.$dash_category_total.'</h1>';

    } 
    else
    {
     echo'<h1 class="mb-0">No data</h1>'; 
    }
    ?>
          <h3>Students</h3>   
        </div>
        <div class="icon-case">
          <img src="images/favicon/favicon.ico" alt=""></div>
      </div>
    </div>
    <div class="content-2"></div>
  </div>

</div>
<br><br><br><br><br>
<div class="column">

  <div class="contet">
    <div class="cards">
      <div class="card">
        <div class="box">
        <?php
    $con = mysqli_connect("localhost","root","","learnhome");
    $dash_category_query = "SELECT * FROM s1resources, s2resources";
    $dash_category_query_run = mysqli_query($con, $dash_category_query);
    if($dash_category_total = mysqli_num_rows($dash_category_query_run))
    {
      echo'<h1 class="mb-0">'.$dash_category_total.'</h1>';

    } 
    else
    {
     echo'<h1 class="mb-0">No data</h1>'; 
    }
    ?>
          <h3>Resources</h3>   
        </div>
        <div class="icon-case">
          <img src="images/favicon/favicon.ico" alt=""></div>
      </div>
    </div>
  </div>
  

  </div>
</div>
<div class="prob">
  <div class="proba">
<h1>E-Learning Probability Calculator</h1>
<form id="calculatorForm">
    <label for="engagement">Student Engagement (0-100):</label>
    <input type="number" id="engagement" min="0" max="100" required><br><br>
    
    <label for="contentQuality">Content Quality (0-100):</label>
    <input type="number" id="contentQuality" min="0" max="100" required><br><br>
    
    <label for="priorKnowledge">Prior Knowledge (0-100):</label>
    <input type="number"  id="priorKnowledge" min="0" max="100" required><br><br>
    
    <label for="dedication">Dedication (0-100):</label>
    <input type="number" id="dedication" min="0" max="100" required><br><br>
    
    <button type="button" style="background-color: red;" onclick="calculateProbability()">Calculate Probability</button>
</form>
  </div>
<p id="result"></p>

<script>
function calculateProbability() {
    const engagement = parseInt(document.getElementById('engagement').value);
    const contentQuality = parseInt(document.getElementById('contentQuality').value);
    const priorKnowledge = parseInt(document.getElementById('priorKnowledge').value);
    const dedication = parseInt(document.getElementById('dedication').value);
    
    // Calculate the average score
    const averageScore = (engagement + contentQuality + priorKnowledge + dedication) / 4;
    
    // Calculate the probability based on the average score
    let probability = 0;
    if (averageScore >= 80) {
        probability = 100; // 100% probability of excelling
    } else {
        probability = averageScore; // Use the average score as the probability
    }
    
    // Display the result
    document.getElementById('result').innerText = `Probability of excelling in exams: ${probability.toFixed(2)}%`;
}
</script>
</div>
</body>
</html>